"""Bubblemaps SHIBA transfer API."""
